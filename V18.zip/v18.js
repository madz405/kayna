Fitur Up
- ttslide2 with apikey
- mediafire2 with apikey
- No Respon Menu/Allmenu/Cmd
- igstalk2 with apikey
- ttstalk withapikey
- togif
- tomp4
- menu, allmenu gifplayback
- fix delay
- fix cekkontol
- fix cekkhodam
- fix list pc
- fix list gc
- paptt++
- delete menu reseller

Note: Jangan Lupa Isi Apikey Biar Fitur Downloader Work Semuaa
Baca Aja Di Settings.js global.raffx & global.btz

Klo Ada Error Langsung Lapor Biar Langsung Di Fix 
Tele : https://t.me/ownerfernazercode