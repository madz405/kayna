exports.stikOtw = [ "https://cdn.filestackcontent.com/iBSvBiZwTrqaLGQbUNUN" ]
exports.stikSpam = [ "https://cdn.filestackcontent.com/496hlMu0REi4lVYmnSpg" ]
exports.stikAdmin = [ "https://cdn.filestackcontent.com/7slmPRDzQjqLVBd0e7G5" ]
exports.stikTagOwn = [ "https://cdn.filestackcontent.com/jbXPAjcHRNSYNalvhbBD" ]