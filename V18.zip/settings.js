const chalk = require("chalk")
const fs = require("fs")
const version = require("@whiskeysockets/baileys/package.json").version


global.language = "id"
global.autoTyping = true 
global.autoRecord = false 
global.autoblockmorroco = true 
global.autokickmorroco = true 
global.antispam = true
global.connect = true
global.pairing = '6285713108053'
global.wlcm = []
global.wlcmm = []
global.versi = '17.0'
global.keyopenai = "sk-jIs2RTjvVgR_WFnutgpAjRTkGdAqleLWaW7eZo1U3wT3BlbkFJ0YU-UsCCDHnlBRtKCtaMw67E-dloPQMNACosFfh0cA" // New
global.btz = 'itFxawCb' // Biar Fitur Play Work Daftar Dapetin Apikey Di : api.betabotz.eu.org // Copy Paste Di google
global.raffx = 'Zl4cNpTq' // Biar Fitur Play Work Daftar Dapetin Apikey Di : api.botcahx.eu.org // Copy Paste Di google
global.logic = 'Kamu adalah Ai'
global.lolhuman = 'f25b5e0f55f1df992f228ce8'
global.storename = "raffx"
global.neoxrapi = "mztHPN" // isi sendiri buat top up otomatis nya
//===============SETTING MENU==================\\
global.thumbnail = fs.readFileSync("./data/image/thumb.jpg")
global.ig = '@ahmd.mldi'
global.yt = '@madzmaa'
global.footer2 = 'D•Light'
global.ttowner = '@just.dreamer18'
global.ownername = 'D•Light'
global.owner = ['6282240327680'] // SETTING JUGA DI FOLDER DATABASE OWNER.json
global.ownernomer = '6282240327680'
global.socialm = 'GitHub: madz405'
global.location = 'Indonesia' 
global.baileysVersion = `Baileys ${version}`
global.new = '120363229775721572@newsletter'
//===============SERVER==================\\
global.apido = ""
global.apilinode = "Api Linode"
global.tokeninstall = "wanzyxamel"
global.bash = "bash <(curl https://raw.githubusercontent.com/wanzy2006/wanzyyoff/main/install.sh)"
global.bash1 = "bash <(curl https://raw.githubusercontent.com/wanzy2006/wanzyyoff/main/install.sh)"
global.tokeninstall1 = "wanzyxamel"
global.bash2 = "bash <(curl https://raw.githubusercontent.com/wanzy2006/wanzyyoff/main/install.sh)"
global.tokeninstall2 = "wanzyxamel"
global.zone = ""
global.apidomain = ""
//========================setting Payment=====================\\
global.nodana = '083188798484' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '083188798484' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = '' // KOSONG KAN JIKA TIDAK ADA
//==================setting Payment Name===========================\\
global.andana = 'ahmadmuldy' // KOSONG KAN JIKA TIDAK ADA
global.angopay = 'Ahmad Muldi' // KOSONG KAN JIKA TIDAK ADA
global.anovo = '' // KOSONG KAN JIKA TIDAK ADA
//==================setting bot===========================\\
global.botname = "Kayna A.I"
global.ownernumber = '6282240327680'
global.botnumber = '6285715949271'
global.ownername = 'D•Light'
global.ownerNumber = ["6282240327680@s.whatsapp.net"]
global.ownerweb = ""
global.websitex = ""
global.gris = '`'
global.wagc = "https://whatsapp.com/channel/0029Va"
global.saluran = "https://whatsapp.com/channel/0029VamJ4o7qMBAo0GX1o"
global.themeemoji = '🪀'
global.wm = "©2024 | Kayna A.I"
global.botscript = 'https://wa.me6282240327680' //script link
global.packname = "Sticker By"
global.author = "\nKayna A.I ©Madz"
global.creator = "6282240327680@s.whatsapp.net"
//======================== CPANEL FITUR ===========================\\
global.domain = 'https://agapeganteng.panellofficial.site' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_cVKTz7IDuO9Ef21wzrajObDoTgha2IOizhsU8uek17i' // Isi Apikey Plta Lu
global.capikey = 'ptlc_47qFKpSeMJQd23z7x4lmfwsxwkwXAlmPlCn5BzGsGUJ' // Isi Apikey Pltc Lu
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah
global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
global.hiasan2 = `	◦  `
global.chat = 'Bangun Sayang Sudah Jam'
//===============SHOP==================\\
global.fotoPakaian = ["https://telegra.ph/file/a2df78368a21a3efc9f34.jpg",
"https://telegra.ph/file/7583097174a260eeffcaf.jpg"]
global.fotoHijab = [""]
global.fotoDistro = [""]
//===========================//
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}
//===========================//
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//===============NEW==================\\
//new
global.prefix = ['','!','.','#','&']
global.sessionName = 'session'
global.hituet = 0
global.limit = 30
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//messages
global.mess = {
wait: '🙂🙃😌',
   success: "Sukses",
   on: "Sudah Aktif", 
   off: "Sudah Off",
   query: {
       text: "Teks Nya Mana?",
       link: "Link Nya Mana?",
       rpg: "Admin menonaktifkan fitur *RPG Game* di grup ini!",
   },
   error: {
       fitur: "Mohon Maaf Fitur Eror Silahkan Chat Developer Bot Agar Bisa Segera Diperbaiki",
   },
   block: {
Bowner: `Maaf kak command 「 *Command* 」 telah di block oleh owner`,
Bsystem: `Command 「 *Command* 」telah di block oleh system karena terjadi error`
},
   only: {
       group: "Maaf Fitur Ini Hanya Bisa Digunakan Di Dalam Group",
       private: "Maaf Fitur Ini Hanya Bisa Digunakan Di Dalam Private Chat",
       owner: "Maaf Fitur Ini Hanya Bisa Digunakan Sama Owner Atau Reseller Bot",
       reseller: "Maaf Fitur Ini Hanya Bisa Digunakan Sama Reseller",       
       admin: "Maaf Fitur Ini Hanya Bisa Digunakan Sama Owner Bot",
       badmin: "Maaf Kaya Nya Kakak Tidak Bisa Menggunakan Fitur Ini Di Karenakan Bot Bukan Admin Group",
       premium: "ᴍᴀᴀғ ᴋᴀᴍᴜ ʙᴇʟᴏᴍ ᴍᴇɴᴊᴀᴅɪ ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴘʀᴇᴍɪᴜᴍ sɪʟᴀᴋᴀɴ ʙᴇʟɪ ᴅɪ ᴏᴡɴᴇʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ᴋᴇᴛɪᴋ  .ᴏᴡɴᴇʀ",
   }
}
 
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
